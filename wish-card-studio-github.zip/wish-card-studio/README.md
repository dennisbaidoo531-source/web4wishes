# Wish Card Studio

**Dennis Interface For Wishes.** A free greeting card designer that runs entirely in the browser. Pick an occasion, draw, stamp, add photos and wishes, then save the card as an image to send.

**Live site:** `https://YOUR-USERNAME.github.io/wish-card-studio/` (replace after you publish, see below)

![Opening screen](screenshots/1-opening-screen.png)

## What it does

- **Opening scene:** an envelope that opens onto your card, with a name and occasion picker.
- **Two-sided cards:** design the Front and the Inside, and save both sides as one image.
- **Occasions:** Birthday, Anniversary, Congratulations, Thank You, Get Well Soon, Holiday Wishes and Custom, each with its own paper, headline and stamps.
- **Drawing tools:** pen, marker, rainbow and sparkle brushes, eraser, line, box, oval, mirror drawing.
- **Shapes and stamps:** heart, star, flower, sun, cloud, speech bubble, plus 36 emoji stamps.
- **Text:** six lettering styles, outlines, wrapped messages, and a "Suggest a wish" button with ready-made messages.
- **Photos:** add a picture, resize, rotate, crop round, add a white border, apply a look (black and white, sepia, warm, vivid, soft).
- **Paper and frames:** confetti, dots, stripes, stars, gradient, custom colour; single, double, dotted and scalloped frames.
- **Editing:** move, resize, rotate, duplicate, reorder, recolour, undo and redo, keyboard nudging.
- **Saving:** PNG, JPG, both sides as one image, or a project file you can reopen later.
- **Extras:** confetti celebration with a short jingle (can be switched off), light and dark themes, works on phones.

![Front of a card](screenshots/2-front-of-card.png)
![Inside of a card](screenshots/3-inside-of-card.png)

## Publish it free with GitHub Pages

1. Create a free account at <https://github.com> and click **New repository**.
2. Name it `wish-card-studio`, set it to **Public**, and create it.
3. Click **uploading an existing file**, drag in everything from this folder (`index.html`, `README.md`, `LICENSE` and the `screenshots` folder), and click **Commit changes**.
4. Open **Settings > Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**, pick the `main` branch and the `/ (root)` folder, then **Save**.
5. Wait a minute. Your site is live at `https://YOUR-USERNAME.github.io/wish-card-studio/`. Share that link with anyone.

Then edit this README and replace `YOUR-USERNAME` in the live site link above.

## Run it on your own computer

There is nothing to install. Double-click `index.html`, or serve the folder:

```
python3 -m http.server 8000
```

and open <http://localhost:8000>.

## Good to know

- It is a single static file with no build step, server or database.
- Cards are kept in each visitor's own browser (local storage). Nothing is uploaded anywhere.
- The card lettering loads from Google Fonts, so it needs an internet connection. Without one, the page still works with ordinary fonts.
- Photo looks use a canvas feature that some versions of Safari do not support. The photo still appears, just without the look.

## Files

| File | Purpose |
| --- | --- |
| `index.html` | The whole app |
| `screenshots/` | Pictures used in this README |
| `LICENSE` | MIT licence |

## Licence

MIT. See `LICENSE`.
